<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Laravel</title>
@extends('layout.site')
@section('content')
<h1>Доставка</h1>
@endsection