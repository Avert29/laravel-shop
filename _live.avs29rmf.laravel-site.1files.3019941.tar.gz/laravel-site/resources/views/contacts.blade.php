<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
@extends('layout.site')
@section('content')
  <title>Контакты</title>
  <h1>Контакты</h1>
@endsection