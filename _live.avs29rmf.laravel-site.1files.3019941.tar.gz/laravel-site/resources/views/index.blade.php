@extends('layout.site')

@section('content')
    <h1>Интернет-магазин</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis ducimus eveniet...</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet asperiores corporis...</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab aspernatur assumenda...</p>
@endsection