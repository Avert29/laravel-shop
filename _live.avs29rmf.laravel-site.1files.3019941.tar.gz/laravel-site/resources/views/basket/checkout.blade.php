@extends('layout.site')

@section('content')
    <h1>Оформление заказа</h1>
    <p>Здесь будет форма оформления</p>
@endsection