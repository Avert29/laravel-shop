

<?php $__env->startSection('content'); ?>
    <h1>Оформление заказа</h1>
    <p>Здесь будет форма оформления</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a/avs29rmf/laravel-site/resources/views/basket/checkout.blade.php ENDPATH**/ ?>