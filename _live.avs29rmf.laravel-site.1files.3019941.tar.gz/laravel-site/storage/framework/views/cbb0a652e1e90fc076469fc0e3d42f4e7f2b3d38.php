
<?php $__env->startSection('content'); ?>
<h1>Бренд: <?php echo e($brand->name); ?></h1>
<ul>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('catalog.product', ['slug' => $product->slug])); ?>">
                <?php echo e($product->name); ?>

            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a/avs29rmf/laravel-site/resources/views/catalog/brand.blade.php ENDPATH**/ ?>