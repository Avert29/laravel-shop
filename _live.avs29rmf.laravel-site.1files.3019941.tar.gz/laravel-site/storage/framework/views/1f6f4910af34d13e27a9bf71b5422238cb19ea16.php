

<?php $__env->startSection('content'); ?>
    <h1>Ваша корзина</h1>
    <?php if(count($products)): ?>
        <?php
            $basketCost = 0;
        ?>
        <form action="<?php echo e(route('basket.clear')); ?>" method="post" class="text-right">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-danger mb-4 mt-0">
                Очистить корзину
            </button>
        </form>
        <table class="table table-bordered">
            <tr>
                <th>№</th>
                <th>Наименование</th>
                <th>Цена</th>
                <th>Кол-во</th>
                <th>Стоимость</th>
                <th></th>
            </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $itemPrice = $product->price;
                    $itemQuantity =  $product->pivot->quantity;
                    $itemCost = $itemPrice * $itemQuantity;
                    $basketCost = $basketCost + $itemCost;
                ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <a href="<?php echo e(route('catalog.product', [$product->slug])); ?>">
                            <?php echo e($product->name); ?>

                        </a>
                    </td>
                    <td><?php echo e(number_format($itemPrice, 2, '.', '')); ?></td>
                    <td>
                        <form action="<?php echo e(route('basket.minus', ['id' => $product->id])); ?>"
                              method="post" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="m-0 p-0 border-0 bg-transparent">
                                -
                            </button>
                        </form>
                        <span class="mx-1"><?php echo e($itemQuantity); ?></span>
                        <form action="<?php echo e(route('basket.plus', ['id' => $product->id])); ?>"
                              method="post" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="m-0 p-0 border-0 bg-transparent">
                                +
                            </button>
                        </form>
                    </td>
                    <td><?php echo e(number_format($itemCost, 2, '.', '')); ?></td>
                    <td>
                        <form action="<?php echo e(route('basket.remove', ['id' => $product->id])); ?>"
                              method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="m-0 p-0 border-0 bg-transparent">
                                удалить
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th colspan="4" class="text-right">Итого</th>
                <th><?php echo e(number_format($basketCost, 2, '.', '')); ?></th>
                <th></th>
            </tr>
        </table>
    <?php else: ?>
        <p>Ваша корзина пуста</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a/avs29rmf/laravel-site/resources/views/basket/index.blade.php ENDPATH**/ ?>