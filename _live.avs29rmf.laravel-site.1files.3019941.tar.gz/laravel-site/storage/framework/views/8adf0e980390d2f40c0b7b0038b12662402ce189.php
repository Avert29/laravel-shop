<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        
        <h1>Тест</h1><?php /**PATH /home/a/avs29rmf/laravel-site/resources/views/test.blade.php ENDPATH**/ ?>