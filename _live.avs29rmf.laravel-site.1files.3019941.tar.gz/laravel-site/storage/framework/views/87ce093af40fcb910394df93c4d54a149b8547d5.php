<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Laravel</title>

<?php $__env->startSection('content'); ?>
<h1>Доставка</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a/avs29rmf/laravel-site/resources/views/delivery.blade.php ENDPATH**/ ?>