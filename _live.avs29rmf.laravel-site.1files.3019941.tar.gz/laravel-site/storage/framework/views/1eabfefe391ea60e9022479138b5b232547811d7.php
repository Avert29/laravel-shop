

<?php $__env->startSection('content'); ?>
    <h1>Каталог товаров</h1>

    <p>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque ducimus, eligendi
    exercitationem expedita, iure iusto laborum magnam qui quidem repellat similique
    tempora tempore ullam! Deserunt doloremque impedit quis repudiandae voluptas?
    </p>

    <h2>Разделы каталога</h2>
    <div class="row">
        <?php $__currentLoopData = $roots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $root): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h4><?php echo e($root->name); ?></h4>
                    </div>
                    <div class="card-body p-0">
                        <img src="<?php echo e(asset('img/400x400.png')); ?>" alt="" class="img-fluid">
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('catalog.category', ['slug' => $root->slug])); ?>"
                           class="btn btn-dark">Перейти в раздел</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a/avs29rmf/laravel-site/resources/views/catalog/index.blade.php ENDPATH**/ ?>